import React from "react";
import Counter from "./counter"; // Assuming Counter.js is in the same directory

const App = () => {
  return (
    <div className="App">
      <Counter />
    </div>
  );
};

export default App;